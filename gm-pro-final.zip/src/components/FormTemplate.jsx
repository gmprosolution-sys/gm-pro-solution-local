import React, {useState} from 'react'
import { motion } from 'framer-motion'
import CONFIG from '../config'

export default function FormTemplate({formType, fields}){
  const [status, setStatus] = useState('')

  async function handleSubmit(e){
    e.preventDefault()
    setStatus('Sending...')
    const data = {}
    fields.forEach(f => data[f.name] = e.target[f.name].value)
    data.formType = formType

    try {
      const zapierPromise = fetch(CONFIG.ZAPIER_URL, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(data)
      })
      const getformPromise = fetch(CONFIG.GETFORM_URL, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(data)
      })
      const results = await Promise.allSettled([zapierPromise, getformPromise])
      const ok = results.every(r => r.status === 'fulfilled')
      if (ok) {
        setStatus('Message sent!')
        e.target.reset()
        setTimeout(()=> setStatus(''), 2200)
      } else {
        setStatus('Some deliveries failed. Check endpoints.')
      }
    } catch(err){
      setStatus('Network error.')
    }
  }

  return (
    <motion.div initial={{opacity:0, y:20}} animate={{opacity:1, y:0}} className="max-w-2xl bg-[#081a25] p-6 rounded-lg">
      <h3 className="text-2xl mb-4">{formType}</h3>
      <form onSubmit={handleSubmit} className="space-y-3">
        {fields.map(f => (
          <div key={f.name} className="flex flex-col">
            <label className="text-sm mb-2 font-medium">{f.label}</label>
            {f.type === 'textarea' ? (
              <textarea name={f.name} required={f.required} rows={4} className="p-3 rounded bg-[#07202b] border border-slate-700"></textarea>
            ) : (
              <input name={f.name} type={f.type} required={f.required} className="p-3 rounded bg-[#07202b] border border-slate-700" />
            )}
          </div>
        ))}
        <div className="flex items-center gap-3 mt-2">
          <button type="submit" className="bg-white text-[#0b2233] px-4 py-2 rounded">Send</button>
          <div className="text-slate-300">{status}</div>
        </div>
      </form>
    </motion.div>
  )
}
