const CONFIG = {
  ZAPIER_URL: "https://hooks.zapier.com/hooks/catch/25300476/usph5ce/",
  GETFORM_URL: "https://getform.io/f/YOUR_KEY"
}
export default CONFIG
