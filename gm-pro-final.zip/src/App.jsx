import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import Contact from './pages/Contact'
import Inspection from './pages/Inspection'
import Taxes from './pages/Taxes'

export default function App(){
  return (
    <div className="min-h-screen bg-[#071827] text-white">
      <header className="py-4 border-b border-slate-800">
        <nav className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <img src="/assets/hero.png" alt="logo" className="w-12 h-12 object-cover rounded-sm" />
            <span className="font-serif text-xl">GM Pro Solution</span>
          </Link>
          <div className="hidden md:flex gap-6 items-center">
            <Link to="/" className="text-slate-200 hover:text-white">Home</Link>
            <Link to="/inspection-request" className="text-slate-200 hover:text-white">Inspection</Link>
            <Link to="/taxes-notary" className="text-slate-200 hover:text-white">Taxes & Notary</Link>
            <Link to="/contact" className="bg-white text-[#0b2233] px-4 py-2 rounded">Contact</Link>
          </div>
        </nav>
      </header>

      <main>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/contact" element={<Contact/>} />
          <Route path="/inspection-request" element={<Inspection/>} />
          <Route path="/taxes-notary" element={<Taxes/>} />
        </Routes>
      </main>

      <footer className="mt-16 py-8 border-t border-slate-800">
        <div className="max-w-6xl mx-auto px-6 text-slate-400 flex justify-between items-center">
          <div>© {new Date().getFullYear()} GM Pro Solution</div>
          <div>407-509-9595</div>
        </div>
      </footer>
    </div>
  )
}
