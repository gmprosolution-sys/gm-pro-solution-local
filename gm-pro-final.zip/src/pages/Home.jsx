import React from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'

export default function Home(){
  return (
    <section className="relative overflow-hidden">
      <div className="max-w-6xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-8 items-center">
        <motion.div initial={{x:-40, opacity:0}} animate={{x:0, opacity:1}} transition={{duration:0.8}}>
          <h1 className="text-5xl font-serif leading-tight mb-6">GM Pro Solution</h1>
          <p className="text-lg text-slate-300 max-w-xl mb-8">We provide vehicle inspections, auto damage appraisal, technical consulting, taxes and notary services — professional, fast and reliable.</p>
          <div className="flex gap-4">
            <Link to="/inspection-request" className="bg-white text-[#0b2233] px-5 py-3 rounded">Request Inspection</Link>
            <Link to="/contact" className="border border-slate-600 px-5 py-3 rounded">Contact</Link>
          </div>
        </motion.div>
        <motion.div initial={{x:40, opacity:0}} animate={{x:0, opacity:1}} transition={{duration:0.9}}>
          <div className="rounded-lg overflow-hidden shadow-xl">
            <img src="/assets/hero.png" alt="hero" className="w-full object-cover" />
          </div>
        </motion.div>
      </div>
    </section>
  )
}
